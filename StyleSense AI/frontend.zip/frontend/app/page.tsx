import Navbar from "@/components/common/Navbar";
import Hero from "@/components/landing/hero/Hero";
import WhySection from "@/components/landing/why/WhySection";
import Features from "@/components/landing/features/Features";
import HowItWorks from "@/components/landing/how-it-works/HowItWorks";

export default function Home() {
  return (
    <main>

      <Navbar />

      <Hero />

      <WhySection />

      <Features />

      <HowItWorks />

    </main>
  );
}

/*"use client";

import api from "@/lib/api";

export default function HomePage() {
  const testBackend = async () => {
    try {
      const res = await api.get("/");

      console.log(res.data);
      alert(res.data.message);
    } catch (error) {
      console.error(error);
      alert("Backend connection failed");
    }
  };

  return (
    <div className="flex h-screen items-center justify-center">
      <button
        onClick={testBackend}
        className="rounded-lg bg-pink-600 px-6 py-3 text-white"
      >
        Test Backend Connection
      </button>
    </div>
  );
}*/