import Sidebar from "@/components/layout/Sidebar";
import ProtectedRoute from "@/components/auth/ProtectedRoute";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ProtectedRoute>
    <div className="flex min-h-screen">
      <Sidebar />

      <main className="flex-1 p-10">
        {children}
      </main>
    </div>
    </ProtectedRoute>
  );
}