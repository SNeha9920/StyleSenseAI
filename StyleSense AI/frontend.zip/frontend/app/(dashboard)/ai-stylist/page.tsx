import AppHeader from "@/components/layout/AppHeader";

import ChatWindow from "@/components/ai-stylist/ChatWindow";
import ChatInput from "@/components/ai-stylist/ChatInput";
import SuggestedPrompts from "@/components/ai-stylist/SuggestedPrompts";
import AIContextCard from "@/components/ai-stylist/AIContextCard";
import RecommendationCard from "@/components/ai-stylist/RecommendationCard";
import OutfitRecommendation from "@/components/ai-stylist/OutfitRecommendation";
import ProductCarousel from "@/components/ai-stylist/ProductCarousel";
import ConversationHistory from "@/components/ai-stylist/ConversationHistory";

export default function AIStylistPage() {
  return (
    <>
      <AppHeader title="AI Stylist" />

      <div className="space-y-8">

        {/* Suggested Questions */}
        <SuggestedPrompts />

        {/* Chat + Sidebar */}
        <div className="grid lg:grid-cols-3 gap-8">

          {/* Chat */}
          <div className="lg:col-span-2 space-y-5">

            <ChatWindow />

            <ChatInput />

          </div>

          {/* Right Panel */}
          <div className="space-y-6">

            <AIContextCard />

            <RecommendationCard />

          </div>

        </div>

        {/* Outfit Recommendation */}
        <OutfitRecommendation />

        {/* Shopping Suggestions */}
        <ProductCarousel />

        {/* Conversation History */}
        <ConversationHistory />

      </div>
    </>
  );
}