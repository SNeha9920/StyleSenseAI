import AppHeader from "@/components/layout/AppHeader";

import HistoryStats from "@/components/history/HistoryStats";
import SearchHistory from "@/components/history/SearchHistory";
import HistoryFilters from "@/components/history/HistoryFilters";
import Timeline from "@/components/history/Timeline";
import SkinHistoryCard from "@/components/history/SkinHistoryCard";
import TryOnHistoryCard from "@/components/history/TryOnHistoryCard";
import StylistHistoryCard from "@/components/history/StylistHistoryCard";
import SavedOutfits from "@/components/history/SavedOutfits";
import ProgressComparison from "@/components/history/ProgressComparison";
import ExportHistory from "@/components/history/ExportHistory";

export default function HistoryPage() {
  return (
    <>
      <AppHeader title="History" />

      <div className="space-y-8">

        {/* Stats */}
        <HistoryStats />

        {/* Search */}
        <SearchHistory />

        {/* Filters */}
        <HistoryFilters />

        {/* Timeline */}
        <Timeline />

        {/* Skin & Try-On History */}
        <div className="grid lg:grid-cols-2 gap-6">
          <SkinHistoryCard />
          <TryOnHistoryCard />
        </div>

        {/* AI Stylist Conversations */}
        <StylistHistoryCard />

        {/* Saved Outfits */}
        <SavedOutfits />

        {/* Progress Comparison */}
        <ProgressComparison />

        {/* Export */}
        <ExportHistory />

      </div>
    </>
  );
}