import AppHeader from "@/components/layout/AppHeader";

import UserProfileCard from "@/components/profile/UserProfileCard";
import PersonalInfo from "@/components/profile/PersonalInfo";
import BodyProfile from "@/components/profile/BodyProfile";
import SkinProfile from "@/components/profile/SkinProfile";
import StylePreferences from "@/components/profile/StylePreferences";
import ShoppingPreferences from "@/components/profile/ShoppingPreferences";
import FavoriteBrands from "@/components/profile/FavoriteBrands";
import MeasurementsCard from "@/components/profile/MeasurementsCard";
import ConnectedAccounts from "@/components/profile/ConnectedAccounts";
import ProfileActions from "@/components/profile/ProfileActions";


export default function ProfilePage() {
  return (
    <>
      <AppHeader title="Profile" />

      <div className="space-y-8">

        <UserProfileCard />

        <PersonalInfo />

        <div className="grid lg:grid-cols-2 gap-8">
          <BodyProfile />
          <SkinProfile />
        </div>

        <StylePreferences />

        <ShoppingPreferences />

        <FavoriteBrands />

        <MeasurementsCard />

        <ConnectedAccounts />

        <ProfileActions />

      </div>
    </>
  );
}