import AppHeader from "@/components/layout/AppHeader";

import UploadPersonCard from "@/components/virtual-try-on/UploadPersonCard";
import ClothingSourceCard from "@/components/virtual-try-on/ClothingSourceCard";
import OutfitGallery from "@/components/virtual-try-on/OutfitGallery";
import TryOnLoader from "@/components/virtual-try-on/TryOnLoader";
import ResultCard from "@/components/virtual-try-on/ResultCard";
import MatchScoreCard from "@/components/virtual-try-on/MatchScoreCard";
import FashionFeedback from "@/components/virtual-try-on/FashionFeedback";
import ShopSimilar from "@/components/virtual-try-on/ShopSimilar";
import SaveOutfitCard from "@/components/virtual-try-on/SaveOutfitCard";
import AIMixBreakdown from "@/components/virtual-try-on/AIMixBreakdown";

export default function VirtualTryOnPage() {
  return (
    <>
      <AppHeader title="Virtual Try-On" />

      <div className="space-y-8">

        <UploadPersonCard />

        <ClothingSourceCard />

        <OutfitGallery />

        <TryOnLoader />

        <ResultCard />

        <div className="grid lg:grid-cols-2 gap-6">
          <MatchScoreCard />
          <FashionFeedback />
        </div>

        <AIMixBreakdown />

        <ShopSimilar />

        <SaveOutfitCard />

      </div>
    </>
  );
}