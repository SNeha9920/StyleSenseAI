import AppHeader from "@/components/layout/AppHeader";
import UploadCard from "@/components/skin-analysis/UploadCard";
import SkinScoreCard from "@/components/skin-analysis/SkinScoreCard";
import ConcernsCard from "@/components/skin-analysis/ConcernsCard";
import AIExplanation from "@/components/skin-analysis/AIExplanation";
import RoutineCard from "@/components/skin-analysis/RoutineCard";
import IngredientsCard from "@/components/skin-analysis/IngredientsCard";
import ProductsCard from "@/components/skin-analysis/ProductsCard";
import ProgressCard from "@/components/skin-analysis/ProgressCard";
import LaunchTryOnCard from "@/components/skin-analysis/LaunchTryOnCard";

export default function SkinAnalysisPage() {
  return (
    <>
      <AppHeader title="Skin Analysis" />

      <div className="space-y-8">

        <UploadCard />

        <div className="grid lg:grid-cols-2 gap-6">
          <SkinScoreCard />
          <ConcernsCard />
        </div>

        <AIExplanation />

        <RoutineCard />

        <div className="grid lg:grid-cols-2 gap-6">
          <IngredientsCard />
          <ProductsCard />
        </div>

        <ProgressCard />

        <LaunchTryOnCard />

      </div>
    </>
  );
}