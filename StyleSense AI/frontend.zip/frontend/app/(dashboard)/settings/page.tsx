import AppHeader from "@/components/layout/AppHeader";

import AppearanceSettings from "@/components/settings/AppearanceSettings";
import NotificationSettings from "@/components/settings/NotificationSettings";
import PrivacySettings from "@/components/settings/PrivacySettings";
import AISettings from "@/components/settings/AISettings";
import AccountSettings from "@/components/settings/AccountSettings";
import SubscriptionCard from "@/components/settings/SubscriptionCard";
import ConnectedApps from "@/components/settings/ConnectedApps";
import DataManagement from "@/components/settings/DataManagement";
import SecuritySettings from "@/components/settings/SecuritySettings";
import SaveSettingsBar from "@/components/settings/SaveSettingsBar";

export default function SettingsPage() {
  return (
    <>
      <AppHeader title="Settings" />

      <div className="space-y-8">

        <AppearanceSettings />

        <NotificationSettings />

        <PrivacySettings />

        <AISettings />

        <div className="grid lg:grid-cols-2 gap-6">
          <AccountSettings />
          <SubscriptionCard />
        </div>

        <ConnectedApps />

        <DataManagement />

        <SecuritySettings />

        <SaveSettingsBar />

      </div>
    </>
  );
}