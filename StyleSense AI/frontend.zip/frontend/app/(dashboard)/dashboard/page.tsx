import AppHeader from "@/components/layout/AppHeader";
import DashboardCard from "@/components/dashboard/DashboardCard";

import {
  Camera,
  Shirt,
  Sparkles,
  BookOpen,
  User,
  History,
} from "lucide-react";

export default function DashboardPage() {
  return (
    <>
      <AppHeader title="Dashboard" />

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

        <DashboardCard
          title="Skin Analysis"
          description="Analyze your skin using AI."
          href="/skin-analysis"
          icon={<Camera />}
        />

        <DashboardCard
          title="Virtual Try-On"
          description="Try outfits virtually."
          href="/virtual-try-on"
          icon={<Shirt />}
        />

        <DashboardCard
          title="AI Stylist"
          description="Get fashion recommendations."
          href="/ai-stylist"
          icon={<Sparkles />}
        />

        <DashboardCard
          title="Wardrobe"
          description="Manage your clothes."
          href="/wardrobe"
          icon={<BookOpen />}
        />

        <DashboardCard
          title="Profile"
          description="Update your account."
          href="/profile"
          icon={<User />}
        />

        <DashboardCard
          title="History"
          description="See previous analyses."
          href="/history"
          icon={<History />}
        />

      </div>
    </>
  );
}