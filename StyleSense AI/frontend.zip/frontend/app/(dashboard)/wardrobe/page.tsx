import AppHeader from "@/components/layout/AppHeader";

import WardrobeStats from "@/components/wardrobe/WardrobeStats";
import SearchFilters from "@/components/wardrobe/SearchFilters";
import AddClothingCard from "@/components/wardrobe/AddClothingCard";
import ClothingGrid from "@/components/wardrobe/ClothingGrid";
import OutfitCollections from "@/components/wardrobe/OutfitCollections";
import RecentItems from "@/components/wardrobe/RecentItems";
import MissingEssentials from "@/components/wardrobe/MissingEssentials";
import ClosetInsights from "@/components/wardrobe/ClosetInsights";

export default function WardrobePage() {
  return (
    <>
      <AppHeader title="Wardrobe" />

      <div className="space-y-8">

        <WardrobeStats />

        <SearchFilters />

        <AddClothingCard />

        <ClothingGrid />

        <OutfitCollections />

        <div className="grid lg:grid-cols-2 gap-8">

          <RecentItems />

          <MissingEssentials />

        </div>

        <ClosetInsights />

      </div>
    </>
  );
}