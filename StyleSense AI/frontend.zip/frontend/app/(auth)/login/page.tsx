import AuthLayout from "@/components/auth/AuthLayout";
import LoginForm from "@/components/auth/LoginForm";
import PublicRoute from "@/components/auth/PublicRoute";

export default function LoginPage() {
  return (
    <PublicRoute>
    <AuthLayout
      title="Welcome Back"
      subtitle="Login to your StyleSense AI account"
    >
      <LoginForm />
    </AuthLayout>
    </PublicRoute>
  );
}