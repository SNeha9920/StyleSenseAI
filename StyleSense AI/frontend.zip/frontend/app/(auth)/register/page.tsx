import AuthLayout from "@/components/auth/AuthLayout";
import RegisterForm from "@/components/auth/RegisterForm";
import PublicRoute from "@/components/auth/PublicRoute";

export default function RegisterPage() {
  return (
    <PublicRoute>
    <AuthLayout
      title="Create Account"
      subtitle="Start your AI beauty & fashion journey"
    >
      <RegisterForm />
    </AuthLayout>
    </PublicRoute>
  );
}