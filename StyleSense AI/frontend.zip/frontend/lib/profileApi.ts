import api from "@/lib/api";

export interface MasterItem {
  id: number;
  name: string;
}

export interface SkinProfile {
  skin_tone: MasterItem | null;
  skin_type: MasterItem | null;
  skin_concerns: MasterItem[];
}

export interface ProfileData {
  id: number;

  // User
  full_name: string;
  email: string;
  profile_image?: string | null;
  gender?: string | null;
  is_active: boolean;

  // Personal
  phone?: string | null;
  location?: string | null;
  date_of_birth?: string | null;

  // Body
  height_cm?: number | null;
  weight_kg?: number | null;
  body_type?: MasterItem | null;
  fit_preference?: MasterItem | null;

  // Skin
  skin_profile?: SkinProfile | null;

  // Shopping
  budget?: number | null;
  shopping_frequency?: string | null;
  preferred_shopping?: string | null;
  sustainable_fashion?: string | null;

  // Measurements
  chest_cm?: number | null;
  waist_cm?: number | null;
  hip_cm?: number | null;
  shoulder_cm?: number | null;
  sleeve_length_cm?: number | null;
  shoe_size?: number | null;

  created_at: string;
  updated_at: string;
}

export interface ProfileUpdateData {
  phone?: string | null;
  location?: string | null;
  date_of_birth?: string | null;

  height_cm?: number | null;
  weight_kg?: number | null;
  body_type_id?: number | null;
  fit_preference_id?: number | null;

  budget?: number | null;
  shopping_frequency?: string | null;
  preferred_shopping?: string | null;
  sustainable_fashion?: string | null;

  chest_cm?: number | null;
  waist_cm?: number | null;
  hip_cm?: number | null;
  shoulder_cm?: number | null;
  sleeve_length_cm?: number | null;
  shoe_size?: number | null;

  skin_tone_id?: number | null;
  skin_type_id?: number | null;
  skin_concern_ids?: number[];
}


// Get current user's profile
export async function getProfile(): Promise<ProfileData> {
  const response = await api.get<ProfileData>("/profile");

  return response.data;
}


// Update current user's profile
export async function updateProfile(
  data: ProfileUpdateData
): Promise<ProfileData> {
  const response = await api.put<ProfileData>(
    "/profile",
    data
  );

  return response.data;
}