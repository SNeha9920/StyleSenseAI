export default function HowItWorks() {

const steps = [
"Upload Selfie",
"Analyze Skin",
"Try Outfits",
"Get AI Advice"
];

return (

<section className="py-20">

<div className="mx-auto max-w-6xl px-6">

<h2 className="text-4xl font-bold text-center">

How It Works

</h2>

<div className="mt-16 grid md:grid-cols-4 gap-8">

{steps.map((step,index)=>(

<div
key={step}
className="rounded-xl border p-6 text-center"
>

<div className="text-4xl font-bold text-violet-600">

{index+1}

</div>

<p className="mt-4">

{step}

</p>

</div>

))}

</div>

</div>

</section>

)

}