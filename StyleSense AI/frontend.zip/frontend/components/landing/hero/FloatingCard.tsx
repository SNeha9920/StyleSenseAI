import { ReactNode } from "react";

interface FloatingCardProps {
  icon: ReactNode;
  title: string;
  description: string;
}

export default function FloatingCard({
  icon,
  title,
  description,
}: FloatingCardProps) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white/80 p-6 shadow-xl backdrop-blur">
      <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-violet-100">
        {icon}
      </div>

      <h3 className="text-lg font-semibold text-slate-900">
        {title}
      </h3>

      <p className="mt-2 text-sm text-slate-500">
        {description}
      </p>
    </div>
  );
}