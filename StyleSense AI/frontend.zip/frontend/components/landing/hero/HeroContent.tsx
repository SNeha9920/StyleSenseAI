import HeroBadge from "./HeroBadge";
import HeroActions from "./HeroActions";

export default function HeroContent() {
  return (
    <div className="max-w-2xl">
      <HeroBadge />

      <h1 className="mt-6 text-5xl font-extrabold leading-tight text-slate-900 lg:text-7xl">
        Your Personal
        <span className="block bg-gradient-to-r from-violet-600 via-fuchsia-500 to-pink-500 bg-clip-text text-transparent">
          Beauty & Fashion
        </span>
        Copilot
      </h1>

      <p className="mt-6 text-lg leading-8 text-slate-600">
        Analyze your skin, virtually try outfits, organize your wardrobe,
        and receive personalized AI styling advice—all in one intelligent
        platform.
      </p>

      <HeroActions />
    </div>
  );
}