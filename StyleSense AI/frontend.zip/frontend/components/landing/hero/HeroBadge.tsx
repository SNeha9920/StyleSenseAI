import { Sparkles } from "lucide-react";

export default function HeroBadge() {
  return (
    <div className="inline-flex items-center gap-2 rounded-full border border-violet-200 bg-violet-50 px-4 py-2 text-sm font-medium text-violet-700 shadow-sm">
      <Sparkles className="h-4 w-4" />
      AI-Powered Beauty & Fashion Assistant
    </div>
  );
}