"use client";
import HeroContent from "./HeroContent";
import HeroVisual from "./HeroVisual";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-violet-50 via-white to-white">
      <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
              backgroundImage: `
              linear-gradient(to right,#000 1px,transparent 1px),
              linear-gradient(to bottom,#000 1px,transparent 1px)
            `,
              backgroundSize: "60px 60px",
          }}
      />
      <div className="mx-auto grid min-h-screen max-w-7xl items-center gap-20 px-6 py-24 lg:grid-cols-2">
        <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
        >
            <HeroContent />
        </motion.div>
        <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
        >
            <HeroVisual />
        </motion.div>
      </div>

      <div className="absolute -top-40 -left-40 h-[500px] w-[500px] rounded-full bg-violet-500/20 blur-[150px]" />

      <div className="absolute top-40 right-0 h-[450px] w-[450px] rounded-full bg-pink-400/20 blur-[140px]" />

      <div className="absolute bottom-0 left-1/2 h-[400px] w-[400px] rounded-full bg-sky-400/20 blur-[130px]" />
    </section>
  );
}