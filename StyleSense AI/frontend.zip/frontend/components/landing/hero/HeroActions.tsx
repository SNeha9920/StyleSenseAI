"use client";

import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Play } from "lucide-react";

export default function HeroActions() {
  return (
    <div className="mt-8 flex flex-col gap-4 sm:flex-row">
      <Button
        size="lg"
        className="rounded-full bg-gradient-to-r from-violet-600 to-pink-500 px-8 py-6 text-base hover:opacity-90"
        onClick={() => router.push("/register")}
      >
        Get Started
      </Button>

      <Button
        size="lg"
        variant="outline"
        className="rounded-full px-8 py-6 text-base"
      >
        <Play className="mr-2 h-4 w-4" />
        Watch Demo
      </Button>
    </div>
  );
}