"use client";

import { motion } from "framer-motion";
import {
    Sparkles,
    Camera,
    Shirt,
    MessageCircle,
} from "lucide-react";

export default function HeroVisual() {
    return (
        <motion.div
            animate={{ y: [0, -8, 0] }}
            transition={{
                duration: 4,
                repeat: Infinity,
            }}
            className="relative"
        >
            <div className="rounded-[40px] border bg-white/80 backdrop-blur-xl p-8 shadow-2xl">

                <div className="flex items-center justify-between">

                    <h2 className="text-2xl font-bold">
                        StyleSense AI
                    </h2>

                    <Sparkles className="text-violet-600" />

                </div>

                <div className="mt-8 space-y-5">

                    <div className="rounded-2xl bg-violet-50 p-5">

                        <div className="flex items-center gap-3">

                            <Camera className="text-violet-600"/>

                            <div>

                                <p className="font-semibold">
                                    Skin Score
                                </p>

                                <p className="text-4xl font-bold">
                                    92%
                                </p>

                            </div>

                        </div>

                    </div>

                    <div className="rounded-2xl bg-pink-50 p-5">

                        <div className="flex items-center gap-3">

                            <Shirt className="text-pink-500"/>

                            <div>

                                <p className="font-semibold">
                                    Outfit Match
                                </p>

                                <p className="text-3xl font-bold">
                                    Excellent
                                </p>

                            </div>

                        </div>

                    </div>

                    <div className="rounded-2xl bg-sky-50 p-5">

                        <div className="flex items-center gap-3">

                            <MessageCircle className="text-sky-600"/>

                            <div>

                                <p className="font-semibold">
                                    AI Stylist
                                </p>

                                <p>
                                    Try pastel colors today ✨
                                </p>

                            </div>

                        </div>

                    </div>

                </div>

            </div>
        </motion.div>
    );
}