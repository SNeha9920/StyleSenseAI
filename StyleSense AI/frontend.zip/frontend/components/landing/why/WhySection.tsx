import {
  Camera,
  Shirt,
  Sparkles,
  BookOpen,
} from "lucide-react";

import WhyCard from "./WhyCard";

export default function WhySection() {
  return (
    <section className="py-20">

      <div className="mx-auto max-w-7xl px-6">

        <h2 className="text-4xl font-bold text-center">
          Why StyleSense AI?
        </h2>

        <p className="mt-4 text-center text-gray-500">
          Everything you need for smarter skincare and fashion decisions.
        </p>

        <div className="mt-14 grid gap-8 md:grid-cols-2 lg:grid-cols-4">

          <WhyCard
            icon={<Camera />}
            title="Know Your Skin"
            description="AI analyzes your skin and detects concerns."
          />

          <WhyCard
            icon={<Shirt />}
            title="Try Before Buying"
            description="Virtually wear clothes before purchasing."
          />

          <WhyCard
            icon={<Sparkles />}
            title="AI Stylist"
            description="Personalized outfit and skincare recommendations."
          />

          <WhyCard
            icon={<BookOpen />}
            title="Wardrobe Manager"
            description="Organize clothes and create outfit combinations."
          />

        </div>

      </div>

    </section>
  );
}