import { ReactNode } from "react";

interface WhyCardProps {
  icon: ReactNode;
  title: string;
  description: string;
}

export default function WhyCard({
  icon,
  title,
  description,
}: WhyCardProps) {
  return (
    <div className="rounded-xl border p-6 shadow-sm hover:shadow-md transition">
      <div className="mb-4">{icon}</div>

      <h3 className="text-xl font-semibold">{title}</h3>

      <p className="mt-3 text-gray-600">{description}</p>
    </div>
  );
}