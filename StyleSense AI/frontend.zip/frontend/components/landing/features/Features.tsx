import {
  Camera,
  Shirt,
  MessageCircle,
  Sparkles,
} from "lucide-react";

import FeatureCard from "./FeatureCard";

export default function Features() {
  return (
    <section className="py-20 bg-gray-50">

      <div className="mx-auto max-w-7xl px-6">

        <h2 className="text-center text-4xl font-bold">
          Core Features
        </h2>

        <div className="mt-14 grid gap-8 md:grid-cols-2">

          <FeatureCard
            icon={<Camera />}
            title="Skin Analysis"
            description="Detect acne, pigmentation, wrinkles and hydration."
          />

          <FeatureCard
            icon={<Shirt />}
            title="Virtual Try-On"
            description="Wear clothes virtually before purchasing."
          />

          <FeatureCard
            icon={<MessageCircle />}
            title="AI Stylist Chat"
            description="Chat with your personal fashion assistant."
          />

          <FeatureCard
            icon={<Sparkles />}
            title="Personalized Recommendations"
            description="Receive skincare and fashion advice."
          />

        </div>

      </div>

    </section>
  );
}