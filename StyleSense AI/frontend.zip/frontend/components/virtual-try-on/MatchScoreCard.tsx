import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

export default function MatchScoreCard() {
  return (
    <Card className="shadow-lg">

      <CardContent className="p-8">

        <h2 className="text-2xl font-bold mb-8">
          Outfit Match Score
        </h2>

        <div className="text-center mb-8">

          <h1 className="text-6xl font-bold text-violet-600">
            96%
          </h1>

          <p className="text-gray-500">
            Excellent Match
          </p>

        </div>

        <div className="space-y-6">

          <div>

            <div className="flex justify-between mb-2">
              <span>Skin Tone</span>
              <span>98%</span>
            </div>

            <Progress value={98} />

          </div>

          <div>

            <div className="flex justify-between mb-2">
              <span>Body Shape</span>
              <span>95%</span>
            </div>

            <Progress value={95} />

          </div>

          <div>

            <div className="flex justify-between mb-2">
              <span>Occasion</span>
              <span>94%</span>
            </div>

            <Progress value={94} />

          </div>

          <div>

            <div className="flex justify-between mb-2">
              <span>Season</span>
              <span>97%</span>
            </div>

            <Progress value={97} />

          </div>

        </div>

      </CardContent>

    </Card>
  );
}