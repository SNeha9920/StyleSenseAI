"use client";

import { useState } from "react";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function ClothingSourceCard() {
  const [selected, setSelected] = useState("mix");

  const options = [
    {
      id: "wardrobe",
      title: "My Wardrobe",
      desc: "Use clothes you've already uploaded.",
    },
    {
      id: "online",
      title: "Online Collection",
      desc: "Browse AI recommended outfits.",
    },
    {
      id: "mix",
      title: "AI Mix",
      desc: "Combine wardrobe + online suggestions.",
    },
  ];

  return (
    <Card className="shadow-lg">

      <CardContent className="p-8">

        <div className="flex items-center justify-between mb-6">

          <h2 className="text-2xl font-bold">
            Choose Outfit Source
          </h2>

          <Badge>Recommended</Badge>

        </div>

        <div className="grid md:grid-cols-3 gap-6">

          {options.map((option) => (

            <div
              key={option.id}
              onClick={() => setSelected(option.id)}
              className={`rounded-xl border p-6 cursor-pointer transition ${
                selected === option.id
                  ? "border-violet-600 bg-violet-50"
                  : "hover:border-violet-400"
              }`}
            >

              <h3 className="font-bold text-lg">
                {option.title}
              </h3>

              <p className="text-gray-500 mt-3">
                {option.desc}
              </p>

            </div>

          ))}

        </div>

      </CardContent>

    </Card>
  );
}