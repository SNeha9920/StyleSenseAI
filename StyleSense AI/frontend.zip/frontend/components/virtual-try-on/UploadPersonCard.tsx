"use client";

import { useRef, useState } from "react";
import { Upload, Camera } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function UploadPersonCard() {
  const inputRef = useRef<HTMLInputElement>(null);

  const [preview, setPreview] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;

    const file = e.target.files[0];

    setPreview(URL.createObjectURL(file));
  };

  return (
    <Card className="shadow-lg">

      <CardContent className="p-8">

        <div className="flex items-center gap-3 mb-6">

          <Upload className="text-violet-600" />

          <div>

            <h2 className="text-2xl font-bold">
              Upload Your Photo
            </h2>

            <p className="text-gray-500">
              Upload a full-body or portrait image for Virtual Try-On.
            </p>

          </div>

        </div>

        <div
          onClick={() => inputRef.current?.click()}
          className="border-2 border-dashed rounded-xl p-10 text-center cursor-pointer hover:border-violet-500 transition"
        >

          {preview ? (
            <img
              src={preview}
              alt="preview"
              className="rounded-xl mx-auto max-h-80"
            />
          ) : (
            <>
              <Camera className="mx-auto h-14 w-14 text-violet-600 mb-4" />

              <h3 className="text-xl font-semibold">
                Drag & Drop Photo
              </h3>

              <p className="text-gray-500 mt-2">
                or click to browse
              </p>

              <Button className="mt-5">
                Choose Image
              </Button>

              <p className="text-xs text-gray-400 mt-4">
                JPG • PNG • JPEG
              </p>
            </>
          )}

          <input
            hidden
            type="file"
            ref={inputRef}
            accept="image/*"
            onChange={handleChange}
          />

        </div>

      </CardContent>

    </Card>
  );
}