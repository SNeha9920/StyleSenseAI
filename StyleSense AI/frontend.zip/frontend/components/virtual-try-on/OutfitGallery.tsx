import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const outfits = [
  {
    name: "Casual Look",
    brand: "StyleNova",
  },
  {
    name: "Office Wear",
    brand: "UrbanWear",
  },
  {
    name: "Party Outfit",
    brand: "TrendHive",
  },
  {
    name: "Summer Collection",
    brand: "ModaCraft",
  },
];

export default function OutfitGallery() {
  return (
    <Card className="shadow-lg">

      <CardContent className="p-8">

        <h2 className="text-2xl font-bold mb-8">

          Suggested Outfits

        </h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">

          {outfits.map((item) => (

            <div
              key={item.name}
              className="rounded-xl border overflow-hidden"
            >

              <div className="h-52 bg-gradient-to-br from-violet-100 to-pink-100" />

              <div className="p-5">

                <h3 className="font-semibold">
                  {item.name}
                </h3>

                <p className="text-gray-500 text-sm mb-5">
                  {item.brand}
                </p>

                <Button className="w-full">
                  Try On
                </Button>

              </div>

            </div>

          ))}

        </div>

      </CardContent>

    </Card>
  );
}