import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, CheckCircle } from "lucide-react";

export default function FashionFeedback() {
  return (
    <Card className="shadow-lg border-violet-200">

      <CardContent className="p-8">

        <div className="flex items-center gap-3 mb-6">

          <Sparkles className="text-violet-600" />

          <h2 className="text-2xl font-bold">
            AI Fashion Copilot
          </h2>

        </div>

        <p className="leading-8 text-gray-700">

          This outfit complements your warm skin tone and enhances your
          overall appearance.

          <br /><br />

          The neutral beige top pairs beautifully with the navy trousers,
          creating a balanced and elegant contrast.

          <br /><br />

          White sneakers add a casual yet premium finish, making this outfit
          suitable for office meetings, brunch outings, or casual events.

        </p>

        <div className="mt-8 space-y-3">

          <div className="flex items-center gap-3">
            <CheckCircle className="text-green-500 h-5 w-5" />
            Great color harmony
          </div>

          <div className="flex items-center gap-3">
            <CheckCircle className="text-green-500 h-5 w-5" />
            Perfect for your body proportions
          </div>

          <div className="flex items-center gap-3">
            <CheckCircle className="text-green-500 h-5 w-5" />
            Recommended confidence level: High
          </div>

        </div>

      </CardContent>

    </Card>
  );
}