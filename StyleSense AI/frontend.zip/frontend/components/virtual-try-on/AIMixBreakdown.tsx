import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shirt, ShoppingBag, Footprints, Watch } from "lucide-react";

const items = [
  {
    icon: <Shirt className="w-5 h-5 text-purple-600" />,
    name: "White Linen Shirt",
    source: "Owned",
    reason: "Matches your skin tone and body shape.",
  },
  {
    icon: <ShoppingBag className="w-5 h-5 text-blue-600" />,
    name: "Navy Slim Chinos",
    source: "AI Suggested",
    price: "₹2,499",
    reason: "Balances your proportions and adds contrast.",
  },
  {
    icon: <Footprints className="w-5 h-5 text-green-600" />,
    name: "White Sneakers",
    source: "Owned",
    reason: "Keeps the outfit casual and clean.",
  },
  {
    icon: <Watch className="w-5 h-5 text-orange-600" />,
    name: "Silver Watch",
    source: "Shopping",
    price: "₹3,999",
    reason: "Completes the premium minimal look.",
  },
];

export default function AIMixBreakdown() {
  return (
    <Card className="shadow-lg rounded-2xl">
      <CardHeader>
        <CardTitle>✨ AI Mix Breakdown</CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">

        {items.map((item, index) => (
          <div
            key={index}
            className="flex justify-between items-start border rounded-xl p-4"
          >

            <div className="flex gap-4">

              <div>{item.icon}</div>

              <div>

                <h3 className="font-semibold">
                  {item.name}
                </h3>

                <p className="text-sm text-gray-500 mt-1">
                  {item.reason}
                </p>

              </div>

            </div>

            <div className="text-right">

              {item.source === "Owned" && (
                <Badge className="bg-green-500">
                  Owned
                </Badge>
              )}

              {item.source === "AI Suggested" && (
                <>
                  <Badge className="bg-blue-500">
                    AI Suggested
                  </Badge>

                  <p className="text-sm mt-2">
                    {item.price}
                  </p>
                </>
              )}

              {item.source === "Shopping" && (
                <>
                  <Badge className="bg-purple-600">
                    Shopping
                  </Badge>

                  <p className="text-sm mt-2">
                    {item.price}
                  </p>
                </>
              )}

            </div>

          </div>
        ))}

      </CardContent>
    </Card>
  );
}