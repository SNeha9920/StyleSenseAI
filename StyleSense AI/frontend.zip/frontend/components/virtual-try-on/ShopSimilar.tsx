import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const products = [
  {
    brand: "StyleNova",
    item: "Beige Linen Shirt",
    price: "₹1,499",
  },
  {
    brand: "UrbanWear",
    item: "White Sneakers",
    price: "₹2,999",
  },
  {
    brand: "TrendHive",
    item: "Brown Leather Belt",
    price: "₹899",
  },
];

export default function ShopSimilar() {
  return (
    <Card className="shadow-lg">

      <CardContent className="p-8">

        <h2 className="text-2xl font-bold mb-8">
          Complete Your Look
        </h2>

        <div className="grid md:grid-cols-3 gap-6">

          {products.map((product) => (

            <div
              key={product.item}
              className="border rounded-xl overflow-hidden"
            >

              <div className="h-52 bg-gradient-to-br from-violet-100 to-pink-100" />

              <div className="p-5">

                <h3 className="font-semibold">
                  {product.item}
                </h3>

                <p className="text-gray-500">
                  {product.brand}
                </p>

                <p className="font-bold mt-2">
                  {product.price}
                </p>

                <Button className="w-full mt-5">
                  Buy Now
                </Button>

              </div>

            </div>

          ))}

        </div>

      </CardContent>

    </Card>
  );
}