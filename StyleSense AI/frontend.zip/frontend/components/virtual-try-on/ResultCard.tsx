import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function ResultCard() {
  return (
    <Card className="shadow-lg">

      <CardContent className="p-8">

        <h2 className="text-2xl font-bold mb-8">
          Virtual Try-On Result
        </h2>

        <div className="grid md:grid-cols-2 gap-8">

          <div>

            <h3 className="font-semibold mb-4">
              Original Photo
            </h3>

            <div className="h-96 rounded-xl bg-gray-100 flex items-center justify-center">
              User Photo
            </div>

          </div>

          <div>

            <h3 className="font-semibold mb-4">
              AI Generated Look
            </h3>

            <div className="h-96 rounded-xl bg-gradient-to-br from-violet-100 to-pink-100 flex items-center justify-center">
              AI Try-On Result
            </div>

          </div>

        </div>

        <div className="flex gap-4 mt-8">

          <Button>
            Compare
          </Button>

          <Button variant="outline">
            Download
          </Button>

          <Button variant="secondary">
            Try Another Outfit
          </Button>

        </div>

      </CardContent>

    </Card>
  );
}