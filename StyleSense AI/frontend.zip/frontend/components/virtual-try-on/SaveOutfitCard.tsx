import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

import {
  Heart,
  Download,
  Share2,
  ShoppingBag,
  Shirt,
} from "lucide-react";

export default function SaveOutfitCard() {
  return (
    <Card className="shadow-xl bg-gradient-to-r from-violet-50 to-pink-50">

      <CardContent className="p-10">

        <h2 className="text-3xl font-bold mb-3">

          Love this Outfit?

        </h2>

        <p className="text-gray-600 mb-8">

          Save it to your wardrobe, download it,
          or purchase the missing items.

        </p>

        <div className="grid md:grid-cols-5 gap-4">

          <Button>

            <Heart className="mr-2 h-4 w-4" />

            Save

          </Button>

          <Button variant="outline">

            <Download className="mr-2 h-4 w-4" />

            Download

          </Button>

          <Button variant="outline">

            <Share2 className="mr-2 h-4 w-4" />

            Share

          </Button>

          <Button variant="secondary">

            <ShoppingBag className="mr-2 h-4 w-4" />

            Buy Items

          </Button>

          <Button variant="outline">

            <Shirt className="mr-2 h-4 w-4" />

            Wardrobe

          </Button>

        </div>

      </CardContent>

    </Card>
  );
}