"use client";

import { Progress } from "@/components/ui/progress";
import { Sparkles } from "lucide-react";

export default function TryOnLoader() {
  return (
    <div className="rounded-2xl border bg-white p-8 shadow-lg">

      <div className="flex items-center gap-3 mb-6">

        <Sparkles className="text-violet-600 animate-pulse" />

        <h2 className="text-2xl font-bold">
          AI is Generating Your Virtual Try-On...
        </h2>

      </div>

      <Progress value={70} />

      <div className="mt-8 space-y-4">

        <p>✅ Detecting Body Pose</p>

        <p>✅ Matching Clothing</p>

        <p>✅ Adjusting Lighting</p>

        <p>⏳ Rendering Final Image</p>

      </div>

    </div>
  );
}