"use client";

import { useAuthContext } from "@/contexts/AuthContext";
import logout from "@/lib/logout";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function AppHeader({
  title,
}: {
  title: string;
}) {
  const { user } = useAuthContext();

  return (
    <header className="mb-8 flex items-center justify-between border-b pb-5">

      <div>
        <h1 className="text-4xl font-bold">
          {title}
        </h1>

        
      </div>

      <div className="flex items-center gap-4">

        <p className="mt-1 text-gray-500">
          Hello, {user?.full_name} 👋
        </p>

        <Link href="/profile" className="no-underline text-inherit">
        <div className="flex h-11 w-11 items-center justify-center rounded-full bg-violet-600 text-lg font-semibold text-white">
          {user?.full_name?.charAt(0)}
        </div>
        </Link>

        <Button
          variant="outline"
          onClick={logout}
        >
          Logout
        </Button>

      </div>

    </header>
  );
}