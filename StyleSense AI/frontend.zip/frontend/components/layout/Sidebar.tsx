"use client";

import Link from "next/link";
import {
  LayoutDashboard,
  Camera,
  Shirt,
  Sparkles,
  BookOpen,
  History,
  User,
  Settings,
} from "lucide-react";

const menus = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { name: "Skin Analysis", href: "/skin-analysis", icon: Camera },
  { name: "Virtual Try-On", href: "/virtual-try-on", icon: Shirt },
  { name: "AI Stylist", href: "/ai-stylist", icon: Sparkles },
  { name: "Wardrobe", href: "/wardrobe", icon: BookOpen },
  { name: "History", href: "/history", icon: History },
  { name: "Profile", href: "/profile", icon: User },
  { name: "Settings", href: "/settings", icon: Settings },
];

export default function Sidebar() {
  return (
    <aside className="w-64 min-h-screen border-r bg-white p-6">
      <Link href="/" className="no-underline text-inherit">
      <h1 className="text-2xl font-bold text-violet-600 mb-8">
        StyleSense AI
      </h1>
      </Link>

      <nav className="space-y-2">
        {menus.map((item) => {
          const Icon = item.icon;

          return (
            <Link
              key={item.name}
              href={item.href}
              className="flex items-center gap-3 rounded-lg px-4 py-3 hover:bg-violet-50"
            >
              <Icon size={20} />

              {item.name}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}