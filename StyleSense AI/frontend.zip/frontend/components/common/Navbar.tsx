"use client";

import { useRouter } from "next/navigation";
import Link from "next/link";
import Logo from "./Logo";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const navItems = [
  { label: "Features", href: "#features" },
  { label: "Skin AI", href: "#skin" },
  { label: "Try-On", href: "#tryon" },
  { label: "AI Stylist", href: "#stylist" },
  { label: "Pricing", href: "#pricing" },
];

export default function Navbar() {
  const router = useRouter();

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/60 bg-white/80 backdrop-blur-lg">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6">
        <Logo />

        {/* Desktop */}
        <nav className="hidden items-center gap-8 md:flex">
          {navItems.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className="text-sm font-medium text-slate-600 transition hover:text-violet-600"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Desktop Buttons */}
        <div className="hidden items-center gap-3 md:flex">
          <Button 
            variant="ghost"
            onClick={() => router.push("/login")}>Login</Button>

          <Button 
            className="rounded-full bg-gradient-to-r from-violet-600 to-pink-500 px-6 hover:opacity-90"
            onClick={() => router.push("/register")}>
            Get Started
          </Button>
        </div>

        {/* Mobile */}
        <Sheet>
          <SheetTrigger className="md:hidden inline-flex h-10 w-10 items-center justify-center rounded-md hover:bg-slate-100">
              <Menu className="h-5 w-5" />
          </SheetTrigger>

          <SheetContent side="right">
            <div className="mt-10 flex flex-col gap-6">
              {navItems.map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  className="text-lg font-medium"
                >
                  {item.label}
                </Link>
              ))}

              <Button className="mt-4">
                Get Started
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}