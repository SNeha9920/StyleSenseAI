import { Sparkles } from "lucide-react";

export default function Logo() {
  return (
    <div className="flex items-center gap-2">
      <div className="rounded-xl bg-gradient-to-r from-violet-600 to-pink-500 p-2 shadow-lg">
        <Sparkles className="h-5 w-5 text-white" />
      </div>

      <div className="flex flex-col leading-none">
        <span className="text-xl font-bold tracking-tight text-slate-900">
          StyleSense
        </span>

        <span className="text-xs font-medium tracking-widest text-violet-600 uppercase">
          AI
        </span>
      </div>
    </div>
  );
}