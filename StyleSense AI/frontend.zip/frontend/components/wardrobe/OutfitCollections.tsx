export default function OutfitCollections() {
  const collections = [
    "Office",
    "Casual Weekend",
    "Party Night",
    "Travel",
    "Gym",
    "Wedding",
  ];

  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="text-2xl font-bold mb-6">
        AI Outfit Collections
      </h2>

      <div className="grid md:grid-cols-3 gap-5">

        {collections.map((item) => (
          <div
            key={item}
            className="rounded-xl border p-6 hover:border-purple-500 cursor-pointer transition"
          >
            <div className="h-36 rounded-lg bg-gradient-to-br from-purple-100 to-pink-100 mb-4" />

            <h3 className="font-semibold text-lg">
              {item}
            </h3>

            <p className="text-sm text-gray-500 mt-2">
              AI generated outfits for {item.toLowerCase()}.
            </p>

            <button className="mt-4 bg-purple-600 text-white px-4 py-2 rounded-lg">
              View Collection
            </button>

          </div>
        ))}

      </div>

    </div>
  );
}