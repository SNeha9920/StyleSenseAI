import { Heart, MoreVertical } from "lucide-react";

type Props = {
  name: string;
  category: string;
  brand: string;
};

export default function ClothingCard({
  name,
  category,
  brand,
}: Props) {
  return (
    <div className="rounded-xl border bg-white overflow-hidden shadow-sm">

      <div className="h-56 bg-gradient-to-br from-purple-100 to-pink-100" />

      <div className="p-4">

        <div className="flex justify-between">

          <div>

            <h3 className="font-semibold">
              {name}
            </h3>

            <p className="text-sm text-gray-500">
              {brand}
            </p>

          </div>

          <Heart
            size={18}
            className="text-gray-400"
          />

        </div>

        <span className="inline-block mt-3 px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-xs">
          {category}
        </span>

      </div>

    </div>
  );
}