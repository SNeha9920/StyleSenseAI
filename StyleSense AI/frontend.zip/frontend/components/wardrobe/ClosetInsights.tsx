export default function ClosetInsights() {
  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="text-2xl font-bold mb-6">
        AI Closet Insights
      </h2>

      <div className="space-y-5">

        <div>
          <strong>Wardrobe Score</strong>
          <p className="text-purple-600 font-bold text-2xl">
            89%
          </p>
        </div>

        <div>
          <strong>Most Worn Color</strong>
          <p>Black</p>
        </div>

        <div>
          <strong>Least Used Item</strong>
          <p>Blue Hoodie</p>
        </div>

        <div>
          <strong>Favorite Brand</strong>
          <p>StyleNova</p>
        </div>

        <div>
          <strong>Unused Clothes</strong>
          <p>7 Items</p>
        </div>

        <div>
          <strong>Shopping Suggestion</strong>
          <p>Add more neutral tops.</p>
        </div>

      </div>

    </div>
  );
}