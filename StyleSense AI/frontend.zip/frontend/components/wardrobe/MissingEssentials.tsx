export default function MissingEssentials() {
  const items = [
    "Black Blazer",
    "Formal Shoes",
    "White Sneakers",
    "Leather Belt",
    "Beige Chinos",
  ];

  return (
    <div className="rounded-2xl border bg-gradient-to-r from-purple-50 to-pink-50 p-6">

      <h2 className="text-2xl font-bold mb-4">
        Missing Essentials
      </h2>

      <p className="text-gray-600 mb-6">
        AI analyzed your wardrobe and found these missing essentials.
      </p>

      <div className="space-y-3">

        {items.map((item) => (
          <div
            key={item}
            className="flex justify-between border rounded-lg p-4 bg-white"
          >
            <span>{item}</span>

            <button className="text-purple-600 font-semibold">
              Shop
            </button>

          </div>
        ))}

      </div>

      <div className="mt-6 rounded-xl bg-purple-600 text-white p-4">
        Adding these items could increase outfit combinations by
        <span className="font-bold"> 34%</span>.
      </div>

    </div>
  );
}