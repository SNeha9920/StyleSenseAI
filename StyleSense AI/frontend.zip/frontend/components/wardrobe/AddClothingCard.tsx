"use client";

import { Upload } from "lucide-react";
import { useState } from "react";

export default function AddClothingCard() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="font-bold text-2xl mb-6">
        Add Clothing Item
      </h2>

      <label className="block border-2 border-dashed border-purple-300 rounded-2xl p-10 text-center cursor-pointer hover:border-purple-500 hover:bg-purple-50 transition">

        <Upload
          className="mx-auto text-purple-600"
          size={55}
        />

        <h3 className="font-semibold text-lg mt-5">
          Upload Clothing Image
        </h3>

        <p className="text-gray-500 mt-2">
          Click anywhere or drag & drop your clothing image here.
        </p>

        <p className="text-sm text-gray-400 mt-2">
          JPG, PNG or WEBP (Max 10 MB)
        </p>

        <span className="inline-block mt-6 bg-purple-600 text-white px-6 py-3 rounded-xl font-medium">
          Choose Image
        </span>

        {selectedFile && (
          <div className="mt-6 rounded-xl bg-green-50 border border-green-200 p-4">
            <p className="font-medium text-green-700">
              ✅ Selected File
            </p>

            <p className="text-sm text-gray-700 mt-1">
              {selectedFile.name}
            </p>
          </div>
        )}

        <input
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            if (e.target.files?.length) {
              setSelectedFile(e.target.files[0]);
            }
          }}
        />

      </label>

    </div>
  );
}