export default function SearchFilters() {
  return (
    <div className="rounded-2xl border bg-white p-6">

      <div className="grid md:grid-cols-6 gap-4">

        <input
          placeholder="Search clothes..."
          className="border rounded-lg px-4 py-2"
        />

        <select className="border rounded-lg px-4 py-2">
          <option>Category</option>
          <option>Shirts</option>
          <option>Pants</option>
          <option>Shoes</option>
        </select>

        <select className="border rounded-lg px-4 py-2">
          <option>Season</option>
          <option>Summer</option>
          <option>Winter</option>
        </select>

        <select className="border rounded-lg px-4 py-2">
          <option>Occasion</option>
          <option>Casual</option>
          <option>Office</option>
        </select>

        <select className="border rounded-lg px-4 py-2">
          <option>Color</option>
          <option>Black</option>
          <option>White</option>
        </select>

        <button className="bg-purple-600 text-white rounded-lg">
          Search
        </button>

      </div>

    </div>
  );
}