import ClothingCard from "./ClothingCard";

export default function ClothingGrid() {
  const items = [
    {
      name: "White Linen Shirt",
      category: "Shirt",
      brand: "StyleNova",
    },
    {
      name: "Blue Jeans",
      category: "Pants",
      brand: "UrbanWear",
    },
    {
      name: "White Sneakers",
      category: "Shoes",
      brand: "StreetFit",
    },
    {
      name: "Black Jacket",
      category: "Jacket",
      brand: "TrendHive",
    },
    {
      name: "Leather Belt",
      category: "Accessory",
      brand: "ClassicCo",
    },
    {
      name: "Formal Blazer",
      category: "Blazer",
      brand: "EliteWear",
    },
  ];

  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="font-bold text-2xl mb-6">
        My Wardrobe
      </h2>

      <div className="grid md:grid-cols-3 xl:grid-cols-4 gap-6">

        {items.map((item) => (
          <ClothingCard
            key={item.name}
            name={item.name}
            category={item.category}
            brand={item.brand}
          />
        ))}

      </div>

    </div>
  );
}