export default function ClothingDetailsModal() {
  return (
    <div className="rounded-2xl border bg-white p-8">

      <div className="grid md:grid-cols-2 gap-8">

        <div className="h-96 rounded-xl bg-gradient-to-br from-purple-100 to-pink-100" />

        <div>

          <h2 className="text-3xl font-bold">
            White Linen Shirt
          </h2>

          <div className="space-y-4 mt-6">

            <p><strong>Brand:</strong> StyleNova</p>

            <p><strong>Category:</strong> Shirt</p>

            <p><strong>Color:</strong> White</p>

            <p><strong>Season:</strong> Summer</p>

            <p><strong>Occasion:</strong> Casual</p>

            <p><strong>AI Styling Score:</strong> 96%</p>

          </div>

          <div className="flex gap-4 mt-8">

            <button className="bg-purple-600 text-white px-5 py-2 rounded-xl">
              Try On
            </button>

            <button className="border px-5 py-2 rounded-xl">
              Edit
            </button>

            <button className="border px-5 py-2 rounded-xl text-red-500">
              Delete
            </button>

          </div>

        </div>

      </div>

    </div>
  );
}