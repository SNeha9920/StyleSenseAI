export default function RecentItems() {
  const items = [
    "White Linen Shirt",
    "Black Blazer",
    "Running Shoes",
    "Denim Jacket",
  ];

  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="text-2xl font-bold mb-5">
        Recently Added
      </h2>

      <div className="space-y-4">

        {items.map((item) => (
          <div
            key={item}
            className="flex items-center justify-between border rounded-lg p-4"
          >
            <div>

              <h3 className="font-semibold">
                {item}
              </h3>

              <p className="text-gray-500 text-sm">
                Added 2 days ago
              </p>

            </div>

            <span className="text-purple-600 font-medium">
              New
            </span>

          </div>
        ))}

      </div>

    </div>
  );
}