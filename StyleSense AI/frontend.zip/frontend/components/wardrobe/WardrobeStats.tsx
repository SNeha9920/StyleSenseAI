export default function WardrobeStats() {
  const stats = [
    { title: "Total Items", value: "82" },
    { title: "Categories", value: "12" },
    { title: "Favorite Color", value: "Black" },
    { title: "Outfit Score", value: "89%" },
  ];

  return (
    <div className="grid md:grid-cols-4 gap-5">
      {stats.map((item) => (
        <div
          key={item.title}
          className="rounded-2xl border bg-white p-6 shadow-sm"
        >
          <p className="text-gray-500 text-sm">{item.title}</p>

          <h2 className="text-3xl font-bold mt-2 text-purple-600">
            {item.value}
          </h2>
        </div>
      ))}
    </div>
  );
}