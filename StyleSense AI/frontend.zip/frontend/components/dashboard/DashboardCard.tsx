import Link from "next/link";
import { ReactNode } from "react";

interface Props {
  title: string;
  description: string;
  href: string;
  icon: ReactNode;
}

export default function DashboardCard({
  title,
  description,
  href,
  icon,
}: Props) {
  return (
    <Link href={href}>
      <div className="rounded-xl border p-6 hover:shadow-lg transition">

        <div className="mb-4">
          {icon}
        </div>

        <h3 className="text-xl font-semibold">
          {title}
        </h3>

        <p className="mt-2 text-gray-600">
          {description}
        </p>

      </div>
    </Link>
  );
}