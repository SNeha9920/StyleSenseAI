import { Search } from "lucide-react";

export default function SearchHistory() {
  return (
    <div className="rounded-2xl border bg-white p-6">
      <div className="relative">
        <Search
          size={18}
          className="absolute left-4 top-3 text-gray-400"
        />

        <input
          placeholder="Search analyses, outfits, products..."
          className="w-full border rounded-xl pl-11 py-3 outline-none"
        />
      </div>
    </div>
  );
}