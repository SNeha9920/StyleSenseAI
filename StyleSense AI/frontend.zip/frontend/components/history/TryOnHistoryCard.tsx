export default function TryOnHistoryCard() {
  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="font-bold text-xl mb-5">
        Virtual Try-On
      </h2>

      <div className="grid grid-cols-2 gap-4">

        <div className="h-44 rounded-xl bg-gray-100 flex items-center justify-center">
          Original
        </div>

        <div className="h-44 rounded-xl bg-gradient-to-br from-purple-100 to-pink-100 flex items-center justify-center">
          Result
        </div>

      </div>

      <div className="mt-5">

        <p><b>Outfit:</b> Smart Casual</p>

        <p><b>Match Score:</b> 96%</p>

      </div>

      <button className="mt-5 bg-purple-600 text-white px-5 py-2 rounded-xl">
        View Again
      </button>

    </div>
  );
}