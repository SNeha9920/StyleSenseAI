export default function SkinHistoryCard() {
  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="font-bold text-xl mb-5">
        Skin Analysis
      </h2>

      <div className="h-48 rounded-xl bg-gradient-to-br from-purple-100 to-pink-100 flex items-center justify-center">
        Photo
      </div>

      <div className="mt-5 space-y-2">

        <p><b>Score:</b> 92</p>

        <p><b>Date:</b> 21 July 2026</p>

        <p><b>Concerns:</b> Dry Skin, Pigmentation</p>

      </div>

      <button className="mt-5 bg-purple-600 text-white px-5 py-2 rounded-xl">
        View Report
      </button>

    </div>
  );
}