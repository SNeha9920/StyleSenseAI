export default function SavedOutfits() {
  const outfits = [
    "Office Look",
    "Wedding Outfit",
    "Airport Style",
    "Dinner Outfit",
  ];

  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="text-2xl font-bold mb-6">
        Saved Outfits
      </h2>

      <div className="grid md:grid-cols-4 gap-5">

        {outfits.map((item) => (
          <div
            key={item}
            className="border rounded-xl overflow-hidden"
          >
            <div className="h-40 bg-gradient-to-br from-purple-100 to-pink-100" />

            <div className="p-4">

              <h3 className="font-semibold">
                {item}
              </h3>

              <button className="mt-3 bg-purple-600 text-white px-4 py-2 rounded-lg">
                Try Again
              </button>

            </div>

          </div>
        ))}

      </div>

    </div>
  );
}