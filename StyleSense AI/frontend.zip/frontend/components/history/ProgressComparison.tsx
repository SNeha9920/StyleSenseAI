export default function ProgressComparison() {
  const progress = [
    ["Hydration", "89%"],
    ["Texture", "94%"],
    ["Brightness", "91%"],
    ["Acne Reduction", "86%"],
  ];

  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="text-2xl font-bold mb-6">
        Skin Progress
      </h2>

      <div className="space-y-5">

        {progress.map(([title, value]) => (
          <div key={title}>

            <div className="flex justify-between mb-2">

              <span>{title}</span>

              <span>{value}</span>

            </div>

            <div className="h-2 rounded-full bg-gray-200">

              <div
                className="h-2 rounded-full bg-purple-600"
                style={{ width: value }}
              />

            </div>

          </div>
        ))}

      </div>

    </div>
  );
}