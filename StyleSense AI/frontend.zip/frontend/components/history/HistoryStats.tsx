import { Camera, Shirt, Sparkles, Heart } from "lucide-react";

export default function HistoryStats() {
  const stats = [
    {
      title: "Skin Analyses",
      value: "28",
      icon: <Camera className="text-purple-600" />,
    },
    {
      title: "Virtual Try-Ons",
      value: "115",
      icon: <Shirt className="text-purple-600" />,
    },
    {
      title: "AI Chats",
      value: "62",
      icon: <Sparkles className="text-purple-600" />,
    },
    {
      title: "Saved Looks",
      value: "19",
      icon: <Heart className="text-purple-600" />,
    },
  ];

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((item) => (
        <div
          key={item.title}
          className="rounded-2xl border bg-white p-6 shadow-sm"
        >
          <div className="flex justify-between items-center">
            <div>
              <p className="text-gray-500">{item.title}</p>
              <h2 className="text-3xl font-bold mt-2">{item.value}</h2>
            </div>

            <div>{item.icon}</div>
          </div>
        </div>
      ))}
    </div>
  );
}