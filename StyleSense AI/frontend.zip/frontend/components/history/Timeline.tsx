export default function Timeline() {
  const events = [
    "Skin Analysis Completed",
    "Virtual Try-On Generated",
    "AI Stylist Recommended Outfit",
    "Added Clothing to Wardrobe",
    "Purchased Recommended Product",
  ];

  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="text-2xl font-bold mb-6">
        Recent Activity
      </h2>

      <div className="space-y-5">

        {events.map((event, index) => (
          <div
            key={index}
            className="flex items-start gap-4"
          >
            <div className="w-4 h-4 rounded-full bg-purple-600 mt-2" />

            <div>
              <p className="font-semibold">{event}</p>
              <p className="text-sm text-gray-500">
                2 hours ago
              </p>
            </div>

          </div>
        ))}

      </div>

    </div>
  );
}