import {
  Download,
  FileText,
  Trash2,
} from "lucide-react";

export default function ExportHistory() {
  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="text-2xl font-bold mb-6">
        Export History
      </h2>

      <div className="flex flex-wrap gap-4">

        <button className="flex items-center gap-2 bg-purple-600 text-white px-5 py-3 rounded-xl">
          <FileText size={18} />
          Export PDF
        </button>

        <button className="flex items-center gap-2 border px-5 py-3 rounded-xl">
          <Download size={18} />
          Export CSV
        </button>

        <button className="flex items-center gap-2 border border-red-400 text-red-500 px-5 py-3 rounded-xl">
          <Trash2 size={18} />
          Delete History
        </button>

      </div>

    </div>
  );
}