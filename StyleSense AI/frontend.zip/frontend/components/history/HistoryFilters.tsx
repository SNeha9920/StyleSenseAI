export default function HistoryFilters() {
  return (
    <div className="rounded-2xl border bg-white p-6">

      <div className="grid md:grid-cols-4 gap-4">

        <select className="border rounded-xl p-3">
          <option>All Activities</option>
          <option>Skin Analysis</option>
          <option>Try-On</option>
          <option>AI Stylist</option>
        </select>

        <select className="border rounded-xl p-3">
          <option>Last 7 Days</option>
          <option>Last Month</option>
          <option>Last Year</option>
        </select>

        <select className="border rounded-xl p-3">
          <option>Newest</option>
          <option>Oldest</option>
        </select>

        <button className="bg-purple-600 text-white rounded-xl">
          Apply Filters
        </button>

      </div>

    </div>
  );
}