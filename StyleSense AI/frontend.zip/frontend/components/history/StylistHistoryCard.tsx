export default function StylistHistoryCard() {
  const chats = [
    "Office Outfit Suggestions",
    "Wedding Styling",
    "Capsule Wardrobe",
    "Summer Fashion",
  ];

  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="text-2xl font-bold mb-5">
        AI Stylist Conversations
      </h2>

      <div className="space-y-3">

        {chats.map((chat) => (
          <div
            key={chat}
            className="flex justify-between border rounded-xl p-4"
          >
            <span>{chat}</span>

            <button className="text-purple-600 font-semibold">
              Open
            </button>

          </div>
        ))}

      </div>

    </div>
  );
}