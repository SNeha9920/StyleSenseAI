import { Card, CardContent } from "@/components/ui/card";

import { Sparkles } from "lucide-react";

export default function AIExplanation() {
  return (
    <Card className="shadow-lg border-violet-200">

      <CardContent className="p-8">

        <div className="flex items-center gap-3 mb-6">

          <Sparkles className="text-violet-600" />

          <h2 className="text-xl font-bold">

            AI Beauty Copilot

          </h2>

        </div>

        <p className="leading-8 text-gray-700">

          Your skin appears healthy overall with a strong hydration level
          and smooth texture.

          <br /><br />

          We detected mild pigmentation around the cheeks along with
          slight dryness.

          <br /><br />

          Regular sunscreen, Vitamin C serum, and consistent moisturizing
          can help improve your skin tone while preventing further
          pigmentation.

        </p>

      </CardContent>

    </Card>
  );
}