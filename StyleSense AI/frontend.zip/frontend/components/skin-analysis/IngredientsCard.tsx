import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function IngredientsCard() {
  return (
    <Card className="shadow-lg">

      <CardContent className="p-8">

        <h2 className="text-2xl font-bold mb-6">
          Recommended Ingredients
        </h2>

        <div className="flex flex-wrap gap-3">

          <Badge>Vitamin C</Badge>

          <Badge>Niacinamide</Badge>

          <Badge>Hyaluronic Acid</Badge>

          <Badge>Retinol</Badge>

          <Badge>Ceramides</Badge>

          <Badge>SPF 50</Badge>

        </div>

      </CardContent>

    </Card>
  );
}