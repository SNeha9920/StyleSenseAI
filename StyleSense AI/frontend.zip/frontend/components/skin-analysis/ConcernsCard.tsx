import { Card, CardContent } from "@/components/ui/card";

import { Badge } from "@/components/ui/badge";

export default function ConcernsCard() {
  return (
    <Card className="shadow-lg">

      <CardContent className="p-8">

        <h2 className="text-xl font-bold mb-6">

          Detected Concerns

        </h2>

        <div className="flex flex-wrap gap-3">

          <Badge>Mild Acne</Badge>

          <Badge>Dry Skin</Badge>

          <Badge>Pigmentation</Badge>

          <Badge>Dark Circles</Badge>

        </div>

      </CardContent>

    </Card>
  );
}