import { Card, CardContent } from "@/components/ui/card";

export default function SkinScoreCard() {
  return (
    <Card className="shadow-lg">

      <CardContent className="p-8">

        <h2 className="text-xl font-bold mb-8">

          Skin Health Score

        </h2>

        <div className="text-center">

          <h1 className="text-6xl font-bold text-violet-600">

            92

          </h1>

          <p className="text-gray-500 mt-2">

            Excellent

          </p>

        </div>

        <div className="mt-10 space-y-4">

          <div className="flex justify-between">

            <span>Hydration</span>

            <span>89%</span>

          </div>

          <div className="flex justify-between">

            <span>Texture</span>

            <span>94%</span>

          </div>

          <div className="flex justify-between">

            <span>Brightness</span>

            <span>91%</span>

          </div>

        </div>

      </CardContent>

    </Card>
  );
}