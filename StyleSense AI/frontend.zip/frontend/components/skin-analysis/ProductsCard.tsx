import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const products = [
  {
    name: "Radiance Vitamin C Serum",
    type: "Vitamin C",
  },
  {
    name: "Hydra Glow Moisturizer",
    type: "Moisturizer",
  },
  {
    name: "Daily Shield SPF 50",
    type: "Sunscreen",
  },
];

export default function ProductsCard() {
  return (
    <Card className="shadow-lg">

      <CardContent className="p-8">

        <h2 className="text-2xl font-bold mb-8">
          AI Recommended Products
        </h2>

        <div className="grid md:grid-cols-3 gap-6">

          {products.map((item) => (

            <div
              key={item.name}
              className="border rounded-xl p-5 text-center"
            >

              <div className="h-36 rounded-lg bg-gradient-to-br from-violet-100 to-pink-100 mb-4" />

              <h3 className="font-semibold">
                {item.name}
              </h3>

              <p className="text-gray-500 mb-4">
                {item.type}
              </p>

              <Button className="w-full">
                View Product
              </Button>

            </div>

          ))}

        </div>

      </CardContent>

    </Card>
  );
}