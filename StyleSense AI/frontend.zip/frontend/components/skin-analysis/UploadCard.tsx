"use client";

import { useRef, useState } from "react";
import { Upload, ImagePlus } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function UploadCard() {
  const inputRef = useRef<HTMLInputElement>(null);

  const [preview, setPreview] = useState<string | null>(null);

  const handleFile = (file: File) => {
    const imageUrl = URL.createObjectURL(file);
    setPreview(imageUrl);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;

    handleFile(e.target.files[0]);
  };

  return (
    <Card className="border-0 shadow-lg">
      <CardContent className="p-8">

        <div className="flex items-center gap-3 mb-6">

          <Upload className="h-6 w-6 text-violet-600" />

          <div>

            <h2 className="text-2xl font-bold">
              Upload Selfie
            </h2>

            <p className="text-gray-500">
              Upload a clear front-facing image for AI Skin Analysis.
            </p>

          </div>

        </div>

        <div
          className="border-2 border-dashed rounded-2xl p-10 flex flex-col items-center justify-center text-center cursor-pointer hover:border-violet-500 transition"
          onClick={() => inputRef.current?.click()}
        >

          {preview ? (
            <img
              src={preview}
              alt="Preview"
              className="rounded-xl max-h-80 object-cover"
            />
          ) : (
            <>
              <ImagePlus
                className="h-14 w-14 text-violet-600 mb-4"
              />

              <h3 className="text-xl font-semibold">
                Drag & Drop your photo
              </h3>

              <p className="text-gray-500 mt-2">
                or click to browse
              </p>

              <Button
                className="mt-6"
                type="button"
              >
                Choose Image
              </Button>

              <p className="text-xs text-gray-400 mt-4">
                JPG • JPEG • PNG
              </p>
            </>
          )}

          <input
            ref={inputRef}
            hidden
            type="file"
            accept="image/*"
            onChange={handleChange}
          />

        </div>

      </CardContent>
    </Card>
  );
}