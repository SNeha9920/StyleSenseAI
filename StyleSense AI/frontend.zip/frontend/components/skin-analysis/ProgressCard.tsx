import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

export default function ProgressCard() {
  return (
    <Card className="shadow-lg">

      <CardContent className="p-8">

        <h2 className="text-2xl font-bold mb-8">
          Skin Progress
        </h2>

        <div className="space-y-8">

          <div>

            <div className="flex justify-between mb-2">
              <span>Hydration</span>
              <span>89%</span>
            </div>

            <Progress value={89} />

          </div>

          <div>

            <div className="flex justify-between mb-2">
              <span>Texture</span>
              <span>94%</span>
            </div>

            <Progress value={94} />

          </div>

          <div>

            <div className="flex justify-between mb-2">
              <span>Brightness</span>
              <span>91%</span>
            </div>

            <Progress value={91} />

          </div>

        </div>

      </CardContent>

    </Card>
  );
}