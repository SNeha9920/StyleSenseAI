"use client";

import { Progress } from "@/components/ui/progress";

export default function AnalysisLoader() {
  return (
    <div className="rounded-2xl border bg-white p-8 shadow">

      <h2 className="text-2xl font-bold mb-6">

        AI is Analyzing Your Skin...

      </h2>

      <Progress value={75} />

      <div className="mt-8 space-y-4">

        <p>✅ Detecting Acne</p>

        <p>✅ Detecting Pigmentation</p>

        <p>✅ Detecting Wrinkles</p>

        <p>⏳ Checking Hydration</p>

        <p>⏳ Estimating Skin Age</p>

      </div>

    </div>
  );
}