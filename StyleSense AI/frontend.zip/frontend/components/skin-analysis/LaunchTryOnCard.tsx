import Link from "next/link";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

import { ArrowRight } from "lucide-react";

export default function LaunchTryOnCard() {
  return (
    <Card className="shadow-xl border-violet-200 bg-gradient-to-r from-violet-50 to-pink-50">

      <CardContent className="p-10 text-center">

        <h2 className="text-3xl font-bold mb-4">

          Ready to See Your New Look?

        </h2>

        <p className="text-gray-600 mb-8">

          Apply your personalized skincare recommendations and instantly
          try makeup, hairstyles, and outfits using AI Virtual Try-On.

        </p>

        <Link href="/virtual-try-on">

          <Button size="lg">

            Launch Virtual Try-On

            <ArrowRight className="ml-2 h-5 w-5" />

          </Button>

        </Link>

      </CardContent>

    </Card>
  );
}