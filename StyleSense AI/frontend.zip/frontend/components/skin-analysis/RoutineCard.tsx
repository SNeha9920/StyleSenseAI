import { Card, CardContent } from "@/components/ui/card";
import { Sun, Moon } from "lucide-react";

export default function RoutineCard() {
  return (
    <Card className="shadow-lg">
      <CardContent className="p-8">

        <h2 className="text-2xl font-bold mb-8">
          Recommended Routine
        </h2>

        <div className="grid md:grid-cols-2 gap-8">

          <div className="rounded-xl border p-6">

            <div className="flex items-center gap-3 mb-5">
              <Sun className="text-yellow-500" />
              <h3 className="font-bold text-lg">Morning</h3>
            </div>

            <ul className="space-y-3 text-gray-600">
              <li>✅ Gentle Cleanser</li>
              <li>✅ Vitamin C Serum</li>
              <li>✅ Moisturizer</li>
              <li>✅ SPF 50 Sunscreen</li>
            </ul>

          </div>

          <div className="rounded-xl border p-6">

            <div className="flex items-center gap-3 mb-5">
              <Moon className="text-indigo-500" />
              <h3 className="font-bold text-lg">Night</h3>
            </div>

            <ul className="space-y-3 text-gray-600">
              <li>✅ Face Wash</li>
              <li>✅ Niacinamide Serum</li>
              <li>✅ Retinol Cream</li>
              <li>✅ Night Moisturizer</li>
            </ul>

          </div>

        </div>

      </CardContent>
    </Card>
  );
}