export default function MeasurementsCard() {
  return (
    <div className="rounded-2xl border bg-white p-8">

      <h2 className="text-2xl font-bold mb-6">
        Measurements
      </h2>

      <div className="grid md:grid-cols-3 gap-5">

        <input className="border rounded-lg p-3" placeholder="Chest (cm)" />

        <input className="border rounded-lg p-3" placeholder="Waist (cm)" />

        <input className="border rounded-lg p-3" placeholder="Hip (cm)" />

        <input className="border rounded-lg p-3" placeholder="Shoulder (cm)" />

        <input className="border rounded-lg p-3" placeholder="Sleeve Length (cm)" />

        <input className="border rounded-lg p-3" placeholder="Shoe Size" />

      </div>

    </div>
  );
}