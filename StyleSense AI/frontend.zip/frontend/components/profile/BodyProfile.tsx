export default function BodyProfile() {
  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="text-xl font-bold mb-5">
        Body Profile
      </h2>

      <div className="space-y-4">

        <input
          className="border rounded-lg p-3 w-full"
          placeholder="Height (cm)"
        />

        <input
          className="border rounded-lg p-3 w-full"
          placeholder="Weight (kg)"
        />

        <select className="border rounded-lg p-3 w-full">
          <option>Body Type</option>
          <option>Rectangle</option>
          <option>Pear</option>
          <option>Hourglass</option>
          <option>Apple</option>
        </select>

        <select className="border rounded-lg p-3 w-full">
          <option>Fit Preference</option>
          <option>Regular</option>
          <option>Slim Fit</option>
          <option>Loose Fit</option>
        </select>

      </div>

    </div>
  );
}