export default function FavoriteBrands() {

  const brands = [
    "Nike",
    "Adidas",
    "Zara",
    "H&M",
    "Levi's",
    "Uniqlo",
    "Puma",
    "Roadster",
  ];

  return (
    <div className="rounded-2xl border bg-white p-8">

      <h2 className="text-2xl font-bold mb-6">
        Favorite Brands
      </h2>

      <div className="flex flex-wrap gap-3">

        {brands.map((brand) => (
          <button
            key={brand}
            className="px-5 py-3 rounded-full border hover:bg-purple-50 hover:border-purple-600 transition"
          >
            {brand}
          </button>
        ))}

      </div>

    </div>
  );
}