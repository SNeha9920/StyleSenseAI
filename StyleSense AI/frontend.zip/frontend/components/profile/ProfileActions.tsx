export default function ProfileActions() {
  return (
    <div className="rounded-2xl border bg-white p-8">

      <div className="flex flex-wrap gap-4 justify-end">

        <button className="px-6 py-3 rounded-xl border">
          Reset
        </button>

        <button className="px-6 py-3 rounded-xl border">
          Download Data
        </button>

        <button className="px-6 py-3 rounded-xl border border-red-500 text-red-500">
          Delete Account
        </button>

        <button className="px-6 py-3 rounded-xl bg-purple-600 text-white">
          Save Changes
        </button>

      </div>

    </div>
  );
}