"use client";

import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

import { useAuthContext } from "@/contexts/AuthContext";

export default function UserProfileCard() {
  const { user } = useAuthContext();


  return (
    <div className="rounded-2xl border bg-white p-8 shadow-sm">

      <div className="flex flex-col md:flex-row items-center gap-8">

        <Avatar className="w-28 h-28 text-3xl">
          <AvatarFallback>{user?.full_name.split(" ")[0].split("")[0]}{user?.full_name.split(" ")[1].split("")[0]}</AvatarFallback>
        </Avatar>

        <div className="flex-1">

          <h1 className="text-3xl font-bold">
            {user?.full_name}
          </h1>

          <p className="text-gray-500 mt-2">
            AI Fashion Enthusiast
          </p>

          <div className="mt-5">

            <div className="flex justify-between text-sm mb-2">
              <span>Profile Completion</span>
              <span>82%</span>
            </div>

            <div className="w-full bg-gray-200 rounded-full h-3">
              <div className="bg-purple-600 h-3 rounded-full w-[82%]" />
            </div>

          </div>

        </div>

        <Button>
          Edit Photo
        </Button>

      </div>

    </div>
  );
}