export default function ShoppingPreferences() {
  return (
    <div className="rounded-2xl border bg-white p-8">

      <h2 className="text-2xl font-bold mb-6">
        Shopping Preferences
      </h2>

      <div className="grid md:grid-cols-2 gap-5">

        <select className="border rounded-lg p-3">
          <option>Budget</option>
          <option>Under ₹2,000</option>
          <option>₹2,000 - ₹5,000</option>
          <option>₹5,000 - ₹10,000</option>
          <option>Premium</option>
        </select>

        <select className="border rounded-lg p-3">
          <option>Shopping Frequency</option>
          <option>Weekly</option>
          <option>Monthly</option>
          <option>Occasionally</option>
        </select>

        <select className="border rounded-lg p-3">
          <option>Preferred Shopping</option>
          <option>Online</option>
          <option>Offline</option>
          <option>Both</option>
        </select>

        <select className="border rounded-lg p-3">
          <option>Sustainable Fashion</option>
          <option>Yes</option>
          <option>No</option>
        </select>

      </div>

    </div>
  );
}