"use client";

import { useAuthContext } from "@/contexts/AuthContext";

export default function PersonalInfo() {
  const { user } = useAuthContext();


  return (
    <div className="rounded-2xl border bg-white p-8">

      <h2 className="text-2xl font-bold mb-6">
        Personal Information
      </h2>

      <div className="grid md:grid-cols-2 gap-5">

        <input className="border rounded-lg p-3" placeholder="First Name" value={user?.full_name.split(" ")[0]} />

        <input className="border rounded-lg p-3" placeholder="Last Name" value={user?.full_name.split(" ")[1]} />

        <input className="border rounded-lg p-3" placeholder="Email" value={user?.email} />

        <input className="border rounded-lg p-3" placeholder="Phone" />

        <input className="border rounded-lg p-3" placeholder="Location" />

        <input className="border rounded-lg p-3" placeholder="Date of Birth" />

      </div>

    </div>
  );
}