export default function StylePreferences() {
  const styles = [
    "Minimal",
    "Casual",
    "Formal",
    "Streetwear",
    "Luxury",
    "Traditional",
    "Sporty",
    "Business",
  ];

  return (
    <div className="rounded-2xl border bg-white p-8">

      <h2 className="text-2xl font-bold mb-6">
        Style Preferences
      </h2>

      <div className="grid md:grid-cols-4 gap-4">

        {styles.map((style) => (
          <button
            key={style}
            className="border rounded-xl py-4 hover:bg-purple-50 hover:border-purple-600 transition"
          >
            {style}
          </button>
        ))}

      </div>

    </div>
  );
}