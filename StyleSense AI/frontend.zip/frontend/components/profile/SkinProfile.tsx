export default function SkinProfile() {
  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="text-xl font-bold mb-5">
        Skin Profile
      </h2>

      <div className="space-y-4">

        <select className="border rounded-lg p-3 w-full">
          <option>Skin Tone</option>
          <option>Fair</option>
          <option>Medium</option>
          <option>Warm Beige</option>
          <option>Dark</option>
        </select>

        <select className="border rounded-lg p-3 w-full">
          <option>Skin Type</option>
          <option>Dry</option>
          <option>Normal</option>
          <option>Combination</option>
          <option>Oily</option>
        </select>

        <textarea
          className="border rounded-lg p-3 w-full"
          rows={4}
          placeholder="Skin Concerns"
        />

      </div>

    </div>
  );
}