import { Switch } from "@/components/ui/switch";

const notifications = [
  {
    title: "AI Analysis Complete",
    description: "Receive a notification when your skin analysis finishes.",
  },
  {
    title: "Weekly Fashion Report",
    description: "Get a personalized weekly style summary.",
  },
  {
    title: "Product Recommendations",
    description: "Be notified when AI finds products you'll love.",
  },
  {
    title: "Wardrobe Suggestions",
    description: "Receive outfit recommendations from your wardrobe.",
  },
  {
    title: "New Features & Updates",
    description: "Stay informed about the latest StyleSense AI features.",
  },
];

export default function NotificationSettings() {
  return (
    <div className="rounded-2xl border bg-white p-8 shadow-sm">

      <div className="mb-8">
        <h2 className="text-2xl font-bold">
          Notifications
        </h2>

        <p className="text-gray-500 mt-2">
          Manage how StyleSense AI communicates with you.
        </p>
      </div>

      <div className="space-y-4">

        {notifications.map((item) => (

          <div
            key={item.title}
            className="flex items-center justify-between rounded-xl border p-5 transition hover:bg-gray-50"
          >

            <div className="max-w-xl">

              <h3 className="font-semibold">
                {item.title}
              </h3>

              <p className="text-sm text-gray-500 mt-1">
                {item.description}
              </p>

            </div>

            <Switch defaultChecked />

          </div>

        ))}

      </div>

    </div>
  );
}