export default function ConnectedApps() {

  const apps = [
    "Google",
    "Apple",
    "Instagram",
    "Pinterest",
    "Amazon",
    "Flipkart",
    "Nykaa",
    "Myntra",
  ];

  return (
    <div className="rounded-2xl border bg-white p-8">

      <h2 className="text-2xl font-bold mb-6">
        Connected Apps
      </h2>

      <div className="space-y-4">

        {apps.map((app) => (

          <div
            key={app}
            className="flex items-center justify-between border rounded-xl p-4"
          >

            <span className="font-medium">
              {app}
            </span>

            <button className="bg-purple-600 text-white px-5 py-2 rounded-lg">
              Connect
            </button>

          </div>

        ))}

      </div>

    </div>
  );
}