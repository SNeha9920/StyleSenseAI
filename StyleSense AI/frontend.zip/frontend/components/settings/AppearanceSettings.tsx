export default function AppearanceSettings() {
  return (
    <div className="rounded-2xl border bg-white p-8">

      <h2 className="text-2xl font-bold mb-6">
        Appearance
      </h2>

      <div className="space-y-6">

        <div>
          <label className="font-semibold block mb-3">
            Theme
          </label>

          <div className="flex gap-4">

            <button className="border px-5 py-2 rounded-lg bg-purple-600 text-white">
              Light
            </button>

            <button className="border px-5 py-2 rounded-lg">
              Dark
            </button>

            <button className="border px-5 py-2 rounded-lg">
              System
            </button>

          </div>
        </div>

        <div>
          <label className="font-semibold block mb-3">
            Accent Color
          </label>

          <div className="flex gap-3">

            <div className="w-8 h-8 rounded-full bg-purple-600" />

            <div className="w-8 h-8 rounded-full bg-blue-500" />

            <div className="w-8 h-8 rounded-full bg-pink-500" />

          </div>
        </div>

      </div>

    </div>
  );
}