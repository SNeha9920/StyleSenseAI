export default function AISettings() {
  return (
    <div className="rounded-2xl border bg-white p-8">

      <h2 className="text-2xl font-bold mb-6">
        AI Preferences
      </h2>

      <div className="space-y-6">

        <div>

          <label className="font-semibold block mb-2">
            AI Personality
          </label>

          <select className="border rounded-lg p-3 w-full">

            <option>Fashion Expert</option>

            <option>Professional</option>

            <option>Friendly</option>

          </select>

        </div>

        <div>

          <label className="font-semibold block mb-2">
            Response Length
          </label>

          <select className="border rounded-lg p-3 w-full">

            <option>Short</option>

            <option>Medium</option>

            <option>Detailed</option>

          </select>

        </div>

        <div>

          <label className="font-semibold block mb-2">
            Creativity
          </label>

          <input
            type="range"
            min="0"
            max="100"
            defaultValue="70"
            className="w-full"
          />

        </div>

      </div>

    </div>
  );
}