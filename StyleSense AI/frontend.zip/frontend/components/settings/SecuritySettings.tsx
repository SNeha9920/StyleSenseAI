import { Switch } from "@/components/ui/switch";

const securitySettings = [
  {
    title: "Two-Factor Authentication",
    description:
      "Add an extra layer of security when signing into your account.",
  },
  {
    title: "Login Alerts",
    description:
      "Receive an email whenever your account is accessed from a new device.",
  },
  {
    title: "Show Active Sessions",
    description:
      "Monitor devices currently logged into your StyleSense AI account.",
  },
  {
    title: "Remember Trusted Devices",
    description:
      "Skip verification for devices you've marked as trusted.",
  },
  {
    title: "Biometric Authentication",
    description:
      "Use fingerprint or Face ID on supported devices for faster login.",
  },
];

export default function SecuritySettings() {
  return (
    <div className="rounded-2xl border bg-white p-8 shadow-sm">

      <div className="mb-8">
        <h2 className="text-2xl font-bold">
          Security
        </h2>

        <p className="text-gray-500 mt-2">
          Manage authentication and account security preferences.
        </p>
      </div>

      <div className="space-y-4">

        {securitySettings.map((item) => (

          <div
            key={item.title}
            className="flex items-center justify-between rounded-xl border p-5 hover:bg-gray-50 transition"
          >

            <div className="max-w-xl">

              <h3 className="font-semibold">
                {item.title}
              </h3>

              <p className="text-sm text-gray-500 mt-1">
                {item.description}
              </p>

            </div>

            <Switch defaultChecked />

          </div>

        ))}

      </div>

    </div>
  );
}