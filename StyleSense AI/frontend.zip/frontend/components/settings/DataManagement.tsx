import {
  Download,
  Trash2,
  Database,
} from "lucide-react";

export default function DataManagement() {
  return (
    <div className="rounded-2xl border bg-white p-8">

      <h2 className="text-2xl font-bold mb-6">
        Data Management
      </h2>

      <div className="grid md:grid-cols-2 gap-4">

        <button className="flex items-center gap-3 border rounded-xl p-4">

          <Download />

          Export Profile

        </button>

        <button className="flex items-center gap-3 border rounded-xl p-4">

          <Database />

          Export Wardrobe

        </button>

        <button className="flex items-center gap-3 border rounded-xl p-4">

          <Download />

          Export AI History

        </button>

        <button className="flex items-center gap-3 border border-red-500 text-red-500 rounded-xl p-4">

          <Trash2 />

          Delete All Data

        </button>

      </div>

    </div>
  );
}