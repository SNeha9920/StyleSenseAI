export default function SubscriptionCard() {
  return (
    <div className="rounded-2xl border bg-gradient-to-br from-purple-600 to-indigo-600 text-white p-8">

      <h2 className="text-2xl font-bold">
        Pro Plan
      </h2>

      <p className="mt-2 opacity-90">
        Your subscription is active.
      </p>

      <div className="mt-6 space-y-3">

        <p>✓ Unlimited Skin Analysis</p>

        <p>✓ Unlimited Virtual Try-On</p>

        <p>✓ AI Stylist</p>

        <p>✓ Wardrobe AI</p>

        <p>✓ Priority Support</p>

      </div>

      <button className="mt-8 bg-white text-purple-700 px-6 py-3 rounded-xl font-semibold">
        Upgrade Plan
      </button>

    </div>
  );
}