export default function SaveSettingsBar() {
  return (
    <div className="sticky bottom-5">

      <div className="rounded-2xl border bg-white shadow-xl p-5 flex justify-end gap-4">

        <button className="px-6 py-3 rounded-xl border">
          Cancel
        </button>

        <button className="px-6 py-3 rounded-xl border">
          Reset
        </button>

        <button className="px-6 py-3 rounded-xl bg-purple-600 text-white">
          Save Settings
        </button>

      </div>

    </div>
  );
}