import { Switch } from "@/components/ui/switch";

const privacySettings = [
  {
    title: "Save Uploaded Photos",
    description:
      "Securely store your uploaded images for future analyses and try-ons.",
  },
  {
    title: "AI Personalization",
    description:
      "Allow StyleSense AI to personalize recommendations using your activity.",
  },
  {
    title: "Anonymous Analytics",
    description:
      "Help improve the platform by sharing anonymous usage statistics.",
  },
  {
    title: "Face Detection Permission",
    description:
      "Allow facial landmark detection for more accurate skin analysis and virtual try-on.",
  },
  {
    title: "Location Access",
    description:
      "Use your location to recommend weather-appropriate outfits and local trends.",
  },
];

export default function PrivacySettings() {
  return (
    <div className="rounded-2xl border bg-white p-8 shadow-sm">

      <div className="mb-8">
        <h2 className="text-2xl font-bold">
          Privacy
        </h2>

        <p className="text-gray-500 mt-2">
          Control how your personal information and AI data are used.
        </p>
      </div>

      <div className="space-y-4">

        {privacySettings.map((item) => (

          <div
            key={item.title}
            className="flex items-center justify-between rounded-xl border p-5 hover:bg-gray-50 transition"
          >

            <div className="max-w-xl">

              <h3 className="font-semibold">
                {item.title}
              </h3>

              <p className="text-sm text-gray-500 mt-1">
                {item.description}
              </p>

            </div>

            <Switch defaultChecked />

          </div>

        ))}

      </div>

    </div>
  );
}