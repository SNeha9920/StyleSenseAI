export default function AccountSettings() {
  return (
    <div className="rounded-2xl border bg-white p-8">

      <h2 className="text-2xl font-bold mb-6">
        Account
      </h2>

      <div className="space-y-5">

        <input
          className="border rounded-lg p-3 w-full"
          placeholder="Email"
        />

        <input
          type="password"
          className="border rounded-lg p-3 w-full"
          placeholder="Current Password"
        />

        <input
          type="password"
          className="border rounded-lg p-3 w-full"
          placeholder="New Password"
        />

        <button className="bg-purple-600 text-white px-6 py-3 rounded-xl">
          Change Password
        </button>

      </div>

    </div>
  );
}