export default function AIContextCard() {
  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="font-bold text-xl mb-5">
        AI Context
      </h2>

      <div className="space-y-4 text-sm">

        <div>
          <strong>Skin Tone</strong>
          <p>Warm Beige</p>
        </div>

        <div>
          <strong>Body Type</strong>
          <p>Rectangle</p>
        </div>

        <div>
          <strong>Wardrobe Items</strong>
          <p>82</p>
        </div>

        <div>
          <strong>Favorite Style</strong>
          <p>Minimal Casual</p>
        </div>

      </div>

    </div>
  );
}