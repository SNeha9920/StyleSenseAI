export default function OutfitRecommendation() {
  return (
    <div className="rounded-2xl border bg-gradient-to-r from-purple-50 to-pink-50 p-6">

      <h2 className="font-bold text-xl">
        Outfit of the Day
      </h2>

      <p className="mt-4 text-gray-600">
        White Shirt + Navy Chinos + White Sneakers + Silver Watch
      </p>

      <button className="mt-5 bg-purple-600 text-white px-5 py-2 rounded-xl">
        Try Virtually
      </button>

    </div>
  );
}