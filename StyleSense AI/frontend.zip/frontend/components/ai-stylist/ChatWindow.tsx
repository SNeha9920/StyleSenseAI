import ChatMessage from "./ChatMessage";
import TypingIndicator from "./TypingIndicator";

export default function ChatWindow() {
  return (
    <div className="rounded-2xl border bg-white p-6 shadow-sm space-y-6 h-[650px] overflow-y-auto">

      <ChatMessage
        role="assistant"
        text="Hi! 👋 I'm your AI Stylist. I already know your wardrobe, body type and skin analysis. What would you like help with today?"
      />

      <ChatMessage
        role="user"
        text="I have a dinner tonight. Suggest an outfit."
      />

      <ChatMessage
        role="assistant"
        text="Great! Since it's an evening dinner, I'd recommend smart casual styling with neutral colors."
      />

      <TypingIndicator />

    </div>
  );
}