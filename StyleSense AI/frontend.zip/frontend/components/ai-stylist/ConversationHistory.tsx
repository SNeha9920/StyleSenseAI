export default function ConversationHistory() {
  const chats = [
    "Dinner Outfit",
    "Office Look",
    "Winter Collection",
    "Wedding Styling",
    "Vacation Packing",
  ];

  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="font-bold text-xl mb-5">
        Previous Conversations
      </h2>

      <div className="space-y-3">

        {chats.map((item) => (
          <div
            key={item}
            className="rounded-lg border p-3 hover:bg-gray-50 cursor-pointer"
          >
            {item}
          </div>
        ))}

      </div>

    </div>
  );
}