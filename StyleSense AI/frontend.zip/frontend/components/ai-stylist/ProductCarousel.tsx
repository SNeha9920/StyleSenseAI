export default function ProductCarousel() {
  const products = [
    "Minimal Shirt",
    "Leather Sneakers",
    "Slim Chinos",
    "Classic Watch",
  ];

  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="font-bold text-xl mb-5">
        AI Shopping Suggestions
      </h2>

      <div className="grid md:grid-cols-4 gap-4">

        {products.map((item) => (
          <div
            key={item}
            className="border rounded-xl p-3"
          >
            <div className="h-36 rounded-lg bg-gradient-to-br from-purple-100 to-pink-100" />

            <h3 className="font-semibold mt-3">
              {item}
            </h3>

            <button className="mt-3 w-full bg-black text-white rounded-lg py-2">
              View
            </button>

          </div>
        ))}

      </div>

    </div>
  );
}