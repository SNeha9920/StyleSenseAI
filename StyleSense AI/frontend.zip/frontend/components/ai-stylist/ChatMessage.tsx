type Props = {
  role: "user" | "assistant";
  text: string;
};

export default function ChatMessage({
  role,
  text,
}: Props) {
  return (
    <div
      className={`flex ${
        role === "user" ? "justify-end" : "justify-start"
      }`}
    >
      <div
        className={`max-w-xl rounded-2xl px-5 py-4 text-sm ${
          role === "assistant"
            ? "bg-purple-50 border border-purple-100"
            : "bg-black text-white"
        }`}
      >
        {text}
      </div>
    </div>
  );
}