import { Send } from "lucide-react";

export default function ChatInput() {
  return (
    <div className="rounded-2xl border bg-white p-4 flex gap-3">

      <input
        placeholder="Ask your stylist anything..."
        className="flex-1 outline-none"
      />

      <button className="bg-purple-600 text-white px-5 rounded-xl flex items-center gap-2">
        <Send size={18} />
        Send
      </button>

    </div>
  );
}