export default function TypingIndicator() {
  return (
    <div className="flex items-center gap-2 text-sm text-gray-500">

      <div className="w-2 h-2 rounded-full bg-purple-500 animate-bounce" />

      <div className="w-2 h-2 rounded-full bg-purple-500 animate-bounce delay-150" />

      <div className="w-2 h-2 rounded-full bg-purple-500 animate-bounce delay-300" />

      AI Stylist is typing...

    </div>
  );
}