export default function SuggestedPrompts() {
  const prompts = [
    "Suggest an office outfit",
    "What should I wear for a wedding?",
    "Recommend skincare for dry skin",
    "Create a capsule wardrobe",
    "Show outfits using my wardrobe",
    "Best colors for my skin tone",
  ];

  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="font-bold text-xl mb-5">
        Suggested Prompts
      </h2>

      <div className="flex flex-wrap gap-3">

        {prompts.map((item) => (
          <button
            key={item}
            className="px-4 py-2 rounded-full border hover:bg-purple-50"
          >
            {item}
          </button>
        ))}

      </div>

    </div>
  );
}