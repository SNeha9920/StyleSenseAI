export default function RecommendationCard() {
  return (
    <div className="rounded-2xl border bg-white p-6">

      <h2 className="font-bold text-xl mb-5">
        Today's Recommendation
      </h2>

      <div className="space-y-3">

        <p>✔ White Linen Shirt</p>

        <p>✔ Navy Chinos</p>

        <p>✔ White Sneakers</p>

        <p>✔ Brown Leather Watch</p>

      </div>

    </div>
  );
}